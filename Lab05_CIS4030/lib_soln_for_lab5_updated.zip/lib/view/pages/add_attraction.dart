import 'package:flutter/material.dart';

class AddAttraction extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Attraction"),
      ),
      body: Center(
        child: Text("Add Attraction"),
      ),
    );
  }
}
