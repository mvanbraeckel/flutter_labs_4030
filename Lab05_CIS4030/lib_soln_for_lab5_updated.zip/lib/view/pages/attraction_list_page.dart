import 'package:flutter/material.dart';
import '../../core/models/attraction.dart';
import '../../core/models/guelph_attractions.dart';
import '../../view/components/attraction_card.dart';

class AttractionListPage extends StatelessWidget {
  final List<Attraction> attractions = GuelphAttractions.guelphAttractions;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, index) {
        return AttractionCard(
          index: index,
          attractions: attractions,
        );
      },
      itemCount: attractions.length,
    );
  }
}
