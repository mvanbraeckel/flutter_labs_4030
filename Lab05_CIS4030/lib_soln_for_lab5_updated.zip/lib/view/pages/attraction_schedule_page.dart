import 'package:flutter/material.dart';

class AttractionsSchedulePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Text("Schedule Page"),
    );
  }
}
