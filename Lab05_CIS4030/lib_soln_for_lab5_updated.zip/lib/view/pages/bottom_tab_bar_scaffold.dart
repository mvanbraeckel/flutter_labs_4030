import 'package:flutter/material.dart';
import '../components/filter_dialog.dart';
import './add_attraction.dart';
import './attraction_list_page.dart';
import './attraction_schedule_page.dart';

class BottomTabBarScaffold extends StatefulWidget {
  @override
  State<BottomTabBarScaffold> createState() => _BottomTabBarScaffoldState();
}

class _BottomTabBarScaffoldState extends State<BottomTabBarScaffold> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }



  Map<String, bool> categories = {
    "Picnic": true,
    'Playground':true,
    'hiking':true,
    'Boating': true,
    'Ice-cream':true,
    'Tea': true,
    'Flowers': true,
    'Swimming': true,
    'Camping': true,
    'Education':true,
  };



  void filterCategories(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return FilterDialog(
            key: UniqueKey(),
            categories: categories,
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lab Five Part A"),
        actions: [
          IconButton(
            onPressed: () => filterCategories(context),
            icon: Icon(Icons.filter_list_alt),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => AddAttraction()),
          );
        },
        child: Icon(Icons.add),
      ),
      body: _selectedIndex == 0
          ? AttractionListPage()
          : AttractionsSchedulePage(),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  BottomNavigationBar _buildBottomNavBar() {
    return BottomNavigationBar(
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.list),
          label: "Attractions",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.calendar_today),
          label: "Scheduled",
        ),
      ],
      currentIndex: _selectedIndex,
      selectedItemColor: Colors.amber[800],
      onTap: _onItemTapped,
    );
  }
}
