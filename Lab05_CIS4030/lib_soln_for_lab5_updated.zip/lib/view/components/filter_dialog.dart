import 'package:flutter/material.dart';

class FilterDialog extends StatefulWidget {
  const FilterDialog({
    required Key key,
    required this.categories,
  }) : super(key: key);

  final Map<String, bool> categories;

  @override
  State<FilterDialog> createState() => _FilterDialogState();
}

class _FilterDialogState extends State<FilterDialog> {
  Map<String, bool> categories_copy = {};

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

   widget.categories.forEach((key, value) { 
     categories_copy[key] = value;
   });

  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Adjust Filters"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Wrap(
            children: [
              for(var key in categories_copy.keys)
                _buildCategoryCard(key)
                
            ],
          ),
        ],
      ),
      actions: [
        TextButton(
          child: const Text('Apply'),
          onPressed: () {

            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }

  Widget _buildCategoryCard(String category) {
    return GestureDetector(
      onTap: () {
        setState(() {
          categories_copy[category] = !(categories_copy[category] ?? false);
        });
      },
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Card(
            color:
                (categories_copy[category] ?? false) ? Colors.grey[300] : Colors.white,
            child: Padding(
              padding: EdgeInsets.all(5),
              child: Text(category),
            ),
          ),
          if (categories_copy[category] ?? false)
            Icon(
              Icons.check_circle,
              size: 12,
            ),
        ],
      ),
    );
  }
}
