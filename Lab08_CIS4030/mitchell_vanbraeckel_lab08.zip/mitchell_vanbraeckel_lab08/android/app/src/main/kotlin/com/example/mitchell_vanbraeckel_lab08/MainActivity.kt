package com.example.mitchell_vanbraeckel_lab08

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
