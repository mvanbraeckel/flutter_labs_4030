enum RecipeDifficulty {
  easy,
  medium,
  hard,
}
