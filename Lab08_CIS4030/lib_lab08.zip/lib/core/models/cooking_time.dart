enum CookingTime {
  fast,
  moderate,
  slow,
}
