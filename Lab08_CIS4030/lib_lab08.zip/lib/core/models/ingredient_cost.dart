enum AmountIngredients {
  cheap,
  decent,
  expensive,
}
