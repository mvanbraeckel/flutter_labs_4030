import 'package:flutter/material.dart';
import 'ingredient_cost.dart';
import 'recipe_difficulty.dart';
import 'cooking_time.dart';

class Recipe {
  final String imageUrl;
  final String recipeName;
  final CookingTime cookingTime;
  final AmountIngredients amountOfIngredients;
  final RecipeDifficulty recipeDifficulty;
  final int totalLikes;
  final String recipeAuthor;
  bool isFavourite;
  final List<String> ingredients;
  final List<String> directions;
  final String description;
  final int cookTime;

  Recipe({
    required this.imageUrl,
    required this.recipeName,
    required this.cookingTime,
    required this.amountOfIngredients,
    required this.recipeDifficulty,
    required this.totalLikes,
    required this.recipeAuthor,
    required this.isFavourite,
    required this.ingredients,
    required this.directions,
    required this.description,
    required this.cookTime,
  });
}
