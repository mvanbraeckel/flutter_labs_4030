import 'package:flutter/material.dart';
import '../../core/models/recipe.dart';
import '../../core/models/recipe_provider.dart';
import '../components/recipe_drawer.dart';
import 'package:provider/provider.dart';

import '../components/recipe_card.dart';

class Recipes extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    List<Recipe> recipesList = Provider.of<RecipeProvider>(context).temp_recipe_list;
    return Scaffold(
      appBar: AppBar(
          title: Text('Lab Five Part B'),
        ),
      drawer: RecipeDrawer(),
      body: SafeArea(
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: [
            for(var recipe in recipesList)
              RecipeCard(recipe: recipe), 
          ],
          // children: [
          //   fo
          //   RecipeCard(),
          // ],
        ),
      ),
    );
  }
}
