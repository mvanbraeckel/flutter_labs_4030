import 'package:flutter/material.dart';
import '../../core/models/recipe_provider.dart';
import '../components/recipe_drawer.dart';
import 'package:provider/provider.dart';

import '../../core/models/recipe.dart';

class FavouriteRecipePage extends StatelessWidget {

  List<Recipe> favouriteList(List<Recipe> recipes) {
    List<Recipe> favourites = [];
    recipes.forEach((recipe) { 
      if(recipe.isFavourite) favourites.add(recipe);
    });

    return favourites;
  }

  @override
  Widget build(BuildContext context) {
    var favouritesList = favouriteList(Provider.of<RecipeProvider>(context).temp_recipe_list);
    return Scaffold(
      appBar: AppBar(
        title: Text('Lab Five Part B'),
      ),
      drawer: RecipeDrawer(),
      body: favouritesList.isEmpty
          ? Center(
              child: Text(
                "No Favourites Yet",
                style: TextStyle(
                  fontSize: 30,
                ),
              ),
            )
          : ListView.builder(
              itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(favouritesList[index].recipeName),
                    subtitle: Text(favouritesList[index].recipeAuthor),
                  );

              },
              itemCount: favouritesList.length,
            ),
    );
  }
}
