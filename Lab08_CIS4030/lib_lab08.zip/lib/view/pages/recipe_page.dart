import 'package:flutter/material.dart';
import '../../core/models/recipe.dart';
import 'package:provider/provider.dart';

import '../../core/models/recipe_provider.dart';

class RecipePage extends StatefulWidget {
  final Recipe recipe;

  RecipePage({required this.recipe});

  @override
  State<RecipePage> createState() => _RecipePageState();
}

class _RecipePageState extends State<RecipePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.recipe.recipeName),
        actions: [
          Consumer<RecipeProvider>(builder: (context, recipe, child) {
            return IconButton(
              onPressed: () {
                setState(
                  () {
                    //widget.recipe.isFavourite = !widget.recipe.isFavourite;
                    recipe.changeFavouriteStatus(widget.recipe);
                  },
                );
              },
              icon: Icon(
                widget.recipe.isFavourite
                    ? Icons.favorite
                    : Icons.favorite_border,
                color: Colors.red,
              ),
            );
          })
        ],
      ),
      body: SafeArea(
        child: Container(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 200,
                width: double.infinity,
                child: Image.network(
                  widget.recipe.imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          Text(
                            "Author: ",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            widget.recipe.recipeAuthor,
                            style: TextStyle(fontSize: 18),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Description: ",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            widget.recipe.description,
                            style: TextStyle(fontSize: 18),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Ingredients: ",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          Wrap(
                            children: [
                              for (int i = 0;
                                  i < widget.recipe.ingredients.length;
                                  i++)
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "${i + 1}. ${widget.recipe.ingredients[i]}",
                                    style: TextStyle(fontSize: 18),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Time to Cook: ",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "${widget.recipe.cookTime} mins",
                            style: TextStyle(fontSize: 18),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Directions: ",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          for (int i = 0;
                              i < widget.recipe.directions.length;
                              i++)
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "${i + 1}. ${widget.recipe.directions[i]}",
                                style: TextStyle(fontSize: 18),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
