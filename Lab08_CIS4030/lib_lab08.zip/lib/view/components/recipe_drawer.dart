import 'package:flutter/material.dart';
import '../pages/recipes_page.dart';
import '../pages/settings_page.dart';
import 'package:provider/provider.dart';

import '../../core/models/recipe_provider.dart';
import '../pages/favourite_recipe_page.dart';

class RecipeDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Center(
                child: Text(
              'Recipe App',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            )),
          ),
          ListTile(
            title: const Text('Recipes'),
            leading: Icon(Icons.list_alt),
            onTap: () {
              //Navigator.of(context)
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (BuildContext context) =>Recipes(),
                ),
              );
            },
          ),
          ListTile(
            title: const Text('Favourite Recipes'),
            leading: Icon(
              Icons.favorite,
              color: Colors.red,
            ),
            onTap: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (BuildContext context) => FavouriteRecipePage(),
                ),
              );
            },
          ),
          ListTile(
            title: const Text('Settings'),
            leading: Icon(Icons.settings),
            onTap: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => SettingsPage()));
            },
          ),
        ],
      ),
    );
  }
}
