import 'package:flutter/material.dart';
import '../../core/models/cooking_time.dart';
import '../../core/models/ingredient_cost.dart';
import '../../core/models/recipe.dart';
import '../../core/models/recipe_difficulty.dart';
import '../pages/recipe_page.dart';
import 'package:provider/provider.dart';

import '../../core/models/recipe_provider.dart';

class RecipeCard extends StatefulWidget {
  final Recipe recipe;
  const RecipeCard({
    required this.recipe,
    Key? key,
  }) : super(key: key);

  @override
  State<RecipeCard> createState() => _RecipeCardState();
}

class _RecipeCardState extends State<RecipeCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (BuildContext context) =>
                RecipePage(recipe: widget.recipe),
          ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
            image: DecorationImage(
              image: NetworkImage(
                  widget.recipe.imageUrl), //AssetImage('assets/pasta.jpg'),
              colorFilter: new ColorFilter.mode(
                  Colors.black.withOpacity(0.54), BlendMode.darken),
              fit: BoxFit.fill,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildAuthorAndRecipeDetails(),
              _buildRecipeBottomContent()
            ],
          ),
        ),
      ),
    );
  }

  Row _buildAuthorAndRecipeDetails() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Text(
            widget.recipe.recipeAuthor,
            style: TextStyle(
              fontSize: 10,
              color: Colors.white,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            children: [
              Consumer<RecipeProvider>(builder: (context, recipe, child) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      recipe.changeFavouriteStatus(widget.recipe);
                    });
                  },
                  child: Icon(
                    widget.recipe.isFavourite
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: Colors.red,
                  ),
                );
              }),
              // Text(
              //   widget.recipe.totalLikes.toString(),
              //   style: TextStyle(color: Colors.white, fontSize: 8),
              // ),
            ],
          ),
        ),
      ],
    );
  }

  Column _buildRecipeBottomContent() {
    String time;
    String ingredients;
    String difficulty;

    if (widget.recipe.cookingTime == CookingTime.fast) {
      time = 'fast';
    } else if (widget.recipe.cookingTime == CookingTime.moderate) {
      time = 'moderate';
    } else {
      time = 'slow';
    }

    if (widget.recipe.amountOfIngredients == AmountIngredients.cheap) {
      ingredients = 'cheap';
    } else if (widget.recipe.amountOfIngredients == AmountIngredients.decent) {
      ingredients = 'decent';
    } else {
      ingredients = 'expensive';
    }

    if (widget.recipe.recipeDifficulty == RecipeDifficulty.easy) {
      difficulty = 'easy';
    } else if (widget.recipe.recipeDifficulty == RecipeDifficulty.medium) {
      difficulty = 'medium';
    } else {
      difficulty = 'hard';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5.0),
          child: Text(
            widget.recipe.recipeName,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildIconRow(Icons.schedule, time),
              _buildIconRow(Icons.shopping_bag, ingredients),
              _buildIconRow(Icons.help, difficulty),
            ],
          ),
        ),
      ],
    );
  }

  Row _buildIconRow(IconData icon, String tag) {
    return Row(
      children: [
        Icon(
          //Icons.shopping_bag,
          icon,
          color: Colors.white,
          size: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5.0),
          child: Text(
            tag,
            style: TextStyle(
              fontSize: 8,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
